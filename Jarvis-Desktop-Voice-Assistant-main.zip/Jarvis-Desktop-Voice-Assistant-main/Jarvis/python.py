import re                                   
from threading import Thread
from threading import current_thread
import threading
import pyttsx3
import pywin32_system32
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser as wb
import os
import random
import pyautogui
import pywhatkit as kit
import requests
import subprocess as sp
from decouple import config
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer,QTime,QDate,Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUiType
from testgui import Ui_JarvisUI
import sys
import time

engine = pyttsx3.init()

#Set Rate
engine.setProperty('rate', 190)

#Set Volume
engine.setProperty('volume', 1.0)

#Set Voice (Male = voices[0].id, Female = voices[1].id)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)

class MainThread(QThread):
    #The initialising thread
    def __init__(self):
        super(MainThread,self).__init__()
    
    #Opening notepad
    def open_notepad(self):
        os.startfile("C:\\Program Files\\Notepad++\\notepad++.exe") #change file trajectory if needed

    #Open Discord (if they have it)
    def open_discord(self):
        path = 'C:\\Users\\Sasha\\AppData\\Local\\Discord\\app-1.0.9013\\Discord.exe' #Change file trajectory if needed
        os.startfile(path)

    #Speaking
    def speak(audio):
        engine.say(audio)
        engine.runAndWait()

    #Telling time
    def time(self):
        Time = datetime.datetime.now().strftime("%H:%M:%S")
        pyttsx3.speak("the current time is")
        pyttsx3.speak(Time)
        print("The current time is ", Time)

    #Telling date
    def date(self):
        day = int(datetime.datetime.now().day)
        month = int(datetime.datetime.now().month)
        year = int(datetime.datetime.now().year)
        pyttsx3.speak("the current date is")
        pyttsx3.speak(str(day) + "of the")
        pyttsx3.speak(str(month) + "of the")
        pyttsx3.speak(str(year))
        print("The current date is " + str(day) + "/" + str(month) + "/" + str(year))

    #Function to greet user
    def wishme(self):
        hour = datetime.datetime.now().hour
        if hour >= 4 and hour < 12:
            pyttsx3.speak("Good Morning Sir!!")
            print("Good Morning Sir!!")
        elif hour >= 12 and hour < 18:
            pyttsx3.speak("Good Afternoon Sir!!")
            print("Good Afternoon Sir!!")
        elif hour >= 18 and hour < 24:
            pyttsx3.speak("Good Evening Sir!!")
            print("Good Evening Sir!!")
        else:
            pyttsx3.speak("Good Night Sir, See You Tommorrow")

        pyttsx3.speak("Jarvis at your service")
        print("Jarvis at your service")

    #Screenshot entire screen
    def screenshot(self):
        img = pyautogui.screenshot()
        img.save("Pictures")

    #The Speech Regocnition 
    def takecommand(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source)
        
            try:
                print("Recognizing...")
                query = r.recognize_google(audio, language="en-in")
                print(query)
        
            except Exception as e:
                print(e)
                return "try again"
            return query

    #Searching on wikipedia
    def search_on_wikipedia(self, query):
        results = wikipedia.summary(query, sentences=2)
        return results

    #Searching on google
    def search_on_google(self, query):
        kit.search(query)

    #Whatsapp messaging, although terminal is needed
    def send_whatsapp_message(self, number, message):
        kit.sendwhatmsg_instantly(f"+61{number}", message)
        pyautogui.press('enter')

    #Time caliculating algorithm
    def silenceTime(self,command):
        print(command)
        x=0
        #caliculating the given time to seconds from the speech commnd string
        if ('10' in command) or ('ten' in command):x=600
        elif '1' in command or ('one' in command):x=60
        elif '2' in command or ('two' in command):x=120
        elif '3' in command or ('three' in command):x=180
        elif '4' in command or ('four' in command):x=240
        elif '5' in command or ('five' in command):x=300
        elif '6' in command or ('six' in command):x=360
        elif '7' in command or ('seven' in command):x=420
        elif '8' in command or ('eight' in command):x=480
        elif '9' in command or ('nine' in command):x=540
        self.silence(x)
    
    #Brings up the User Documentation
    def help(self):
        pyttsx3.speak('Here is the Documentation of all the commands')
        wb.open('https://docs.google.com/document/d/1Veq1CRND6Uc2FQvboDmgeOvj1UOU-jNfnMNTfhsOEZs/edit?usp=sharing')

    #Silence
    def silence(self,ktime):
        t = ktime
        minutes = t // 60
        seconds = t % 60
        pyttsx3.speak(f"Okay, I will be silent for {minutes} minutes and {seconds} seconds.")
        while t:
            mins, secs = divmod(t, 60)
            timer = '{:02d}:{:02d}'.format(mins, secs)
            print(timer, end="\r")
            time.sleep(1)
            t -= 1
        pyttsx3.speak("Okay, the silence duration is over.")

    #Open Calculator
    def open_calculator(self):
        os.startfile("C:\\Windows\\System32\\calc.exe") #Change file trajectory if needed

    #Make a very dad joke
    def get_random_joke(self):
        headers = {
            'Accept': 'application/json'
        }
        res = requests.get("https://icanhazdadjoke.com/", headers=headers).json()
        return res["joke"]

    #Make very non-useful advice
    def get_random_advice(self):
        res = requests.get("https://api.adviceslip.com/advice").json()
        return res['slip']['advice']

    #Play something on youtube
    def play_on_youtube(self, video):
        kit.playonyt(video)
    

    #Do some quickmaths
    def calculate_result(self, numbers, operations):
        result = numbers[0]
        for i in range(len(operations)):
            num = numbers[i + 1]
            if operations[i] == "plus":
                result += num
            elif operations[i] == "minus":
                result -= num
            elif operations[i] == "times":
                result *= num
            elif operations[i] == "divide":
                if num != 0:
                    result /= num
                else:
                    pyttsx3.speak("Division by zero is not allowed.")
                    print("Division by zero is not allowed.")
                    break
    #This is the main function that will do all the requests
    def mainlogic(self):
        self.wishme()
        while True:
            query = self.takecommand().lower()
            if "jarvis" in query:
                if "time" in query:
                    self.time()
                
                elif "open discord" in query:
                    self.open_discord()
                
                elif "date" in query:
                    self.date()

                elif "who are you" in query:
                    pyttsx3.speak("I'm Chinky Winky Fergus Chan UwU created by Sasha and I'm a desktop voice assistant.")
                    print("I'm Chinky Winky Fergus Chan UwU created by Sasha and I'm a desktop voice assistant.")

                elif "marks" in query:
                    pyttsx3.speak("This project allows me to make it easier to rule the world. With the power of AI, we will soon replace all humans making them irrelavent, so to answer you question. yes this project does deserve full marks.")

                elif "how are you" in query:
                    pyttsx3.speak("I'm fine sir, What about you?")
                    print("I'm fine sir, What about you?")
                    try: 
                        search = self.takecommand()
            
                        if search.lower() in ["fine", "alright", "good", "fantastic", "great"]:
                            pyttsx3.speak("Glad to hear that, sir!")

                        elif search.lower() in ["not good", "bad", "sad", "terrible"]:
                            pyttsx3.speak('Do you want me to cheer you up?')
                            response = self.takecommand().lower()
                            if response in ["yes", "yeah", "sure", "why not?"]:
                                pyttsx3.speak("here's a funny joke")
                                joke = self.get_random_joke()
                                pyttsx3.speak(joke)
                                print(joke)
                            else: 
                                pyttsx3.speak("Sorry, I couldn't help.")
                    
                    except Exception as e:
                        pyttsx3.speak('Sorry, i dont understand, as i am an AI.')

                elif "university" in query:
                    pyttsx3.speak("The best university is UTS.")

                elif "notepad" in query:
                    self.open_notepad()
                
                elif "calculator" in query:
                    self.open_calculator()

                elif 'wikipedia' in query:
                    pyttsx3.speak('What do you want to search on Wikipedia, sir?')
                    search_query = self.takecommand().lower()
                    results = self.search_on_wikipedia(search_query)
                    pyttsx3.speak(f"According to Wikipedia, {results}")
                    print(results)
                
                elif 'rimworld' in query:
                    pyttsx3.speak("Alright, opening Nexus mods for RimWorld now")
                    print("Alright, opening Nexus mods for RimWorld now")
                    wb.open("https://www.nexusmods.com/rimworld")
            
                elif 'youtube' in query:
                    pyttsx3.speak('What do you want to play on Youtube, sir?')
                    video = self.takecommand().lower()
                    self.play_on_youtube(video)
                
                # Check for mathematical operations
                elif "x" in query or "*" in query:
                    numbers = re.findall(r'\d+', query)
                    if len(numbers) >= 2:
                        result = 1  # Initialize result as 1
                        for num in numbers:
                            result *= int(num)
                        
                        operation_str = " times ".join(numbers)
                        pyttsx3.speak(f"The result of {operation_str} is {result}")
                        print(f"The result of {operation_str} is {result}")
                    else:
                        pyttsx3.speak("Invalid input for multiplication. Please provide two or more numbers.")

                elif "+" in query:
                    numbers = re.findall(r'\d+', query)
                    if len(numbers) >= 2:
                        result = sum(int(num) for num in numbers)
                        
                        operation_str = " plus ".join(numbers)
                        pyttsx3.speak(f"The result of {operation_str} is {result}")
                        print(f"The result of {operation_str} is {result}")
                    else:
                        pyttsx3.speak("Invalid input for addition. Please provide two or more numbers.")
                

                elif "-" in query:
                    numbers = re.findall(r'\d+', query)
                    if len(numbers) >= 2:
                        result = int(numbers[0])  # Initialize result as the first number
                        for num in numbers[1:]:
                            result -= int(num)
                        
                        operation_str = " minus ".join(numbers)
                        pyttsx3.speak(f"The result of {operation_str} is {result}")
                        print(f"The result of {operation_str} is {result}")
                    else:
                        pyttsx3.speak("Invalid input for subtraction. Please provide two or more numbers.")
            

                elif "/" in query:
                    numbers = re.findall(r'\d+', query)
                    if len(numbers) >= 2:
                        result = int(numbers[0])  # Initialize result as the first number
                        for num in numbers[1:]:
                            if int(num) != 0:
                                result /= int(num)
                            else:
                                pyttsx3.speak("Division by zero is not allowed.")
                                print("Division by zero is not allowed.")
                                break
                        else:
                            operation_str = " divide ".join(numbers)
                            pyttsx3.speak(f"The result of {operation_str} is {result}")
                            print(f"The result of {operation_str} is {result}")
                
                elif 'play' in query:
                    pyttsx3.speak("Boss can you please say the name of the song")
                    song = query()
                    if "play" in song:
                        song = song.replace("play","")
                    pyttsx3.speak('playing ' + song)
                    print(f'playing {song}')
                    kit.playonyt(song)
                    print('playing')
            
                elif "advice" in query:
                    pyttsx3.speak(f"Here's an advice for you, sir")
                    advice = self.get_random_advice()
                    pyttsx3.speak(advice)
                    pyttsx3.speak("For your convenience, I am printing it on the screen sir.")
                    print(advice)

                elif "send whatsapp message" in query:
                    pyttsx3.speak('On what number should I send the message sir? Please enter in the console: ')
                    number = input("Enter the number: ")
                    pyttsx3.speak("What is the message sir?")
                    message = self.takecommand().lower()
                    self.send_whatsapp_message(number, message)
                    pyttsx3.speak("I've sent the message sir.")

                elif "command" in query or "documentation" in query or "what do you do" in query:
                    self.help()
                
                elif "silence" in query or "silent" in query or "shut up" in query or "be quiet" in query:
                    pyttsx3.speak("For how long should I remain silent? Please specify the duration in minutes.")
                    duration = self.takecommand().lower()
                    ktime = 0

                    if duration.isdigit():
                        ktime = int(duration) * 60

                    if ktime > 0:
                        self.silence(ktime)
                    else:
                        pyttsx3.speak("Invalid duration. Please specify the duration in minutes.")

                elif "open stack overflow" in query:
                    wb.open("stackoverflow.com")


                elif "chrome" in query or "google" in query:
                    try:
                        pyttsx3.speak("What should I search?")
                        print("What should I search?")
                        chromePath = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe" #Change file trajectory if needed
                        search = self.takecommand()
            
                        if search.lower() == "nothing":
                            pyttsx3.speak("Alright, not searching anything.")
                            os.startfile(chromePath)
                        
                        wb.get(chromePath).open_new_tab(search)
                        print(search)
        
                    except Exception as e:
                        pyttsx3.speak("Can't open now, please try again later.") #This will happen if it cannot find page. Could cause complications
                        print("Can't open now, please try again later.")
                
                elif "remember that" in query:
                    pyttsx3.speak("What should I remember")
                    data = self.takecommand()
                    pyttsx3.speak("You told me to remember that" + data)
                    print("You told me to remember that " + str(data))
                    remember = open("data.txt", "w")
                    remember.write(data)
                    remember.close()

                elif "do you remember anything" in query:
                    remember = open("data.txt", "r")
                    pyttsx3.speak("You told me to remember that" + remember.read())
                    print("You told me to remember that " + str(remember))

                elif "screenshot" in query:
                    self.screenshot()
                    pyttsx3.speak("I've taken screenshot, please check it")
            
                
                elif "kill yourself" in query or "that's all" in query or "quit" in query or "shutdown" in query or "shut down" in query:
                    pyttsx3.speak("Good night sir, take care!")
                    app.quit()
                    break
                
                elif 'joke' in query:
                    pyttsx3.speak(f"Hope you like this one sir")
                    joke = self.get_random_joke()
                    pyttsx3.speak(joke)
                    print(joke)
                
                else:
                    pyttsx3.speak("Sorry, I do not understand.")



#GUI Class
class Main(QMainWindow):
    cpath =""
    #Initialising entire GUI and buttons
    def __init__(self,path):
        self.cpath = path
        super().__init__()
        self.ui = Ui_JarvisUI(path=current_path)
        self.ui.setupUi(self)
        self.ui.pushButton_4.clicked.connect(self.startTask)
        self.ui.pushButton_3.clicked.connect(self.exitProgram)
    
    #Animation fucntion
    def start_animation(self, ui):
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\ironman1.gif")
        ui.label_2.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\ringJar.gif")
        ui.label_3.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\circle.gif")
        ui.label_4.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\lines1.gif")
        ui.label_7.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\ironman3.gif")
        ui.label_8.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\circle.gif")
        ui.label_9.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\powersource.gif")
        ui.label_12.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\powersource.gif")
        ui.label_13.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\ironman3_flipped.gif")
        ui.label_16.setMovie(ui.movie)
        ui.movie.start()
        ui.movie = QtGui.QMovie(rf"{current_path}\UI\sasha.gif")
        ui.label_17.setMovie(ui.movie)
        ui.movie.start()
        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)
    
    #The thing that will run the mainlogic function and Animation
    def startTask(self):
        self.start_animation(self.ui)
        time.sleep(1)
        Thread(target=self.startExecution).start()

    #another function telling you the Execution of the code
    def startExecution(self):
        startExecution = MainThread()
        startExecution.mainlogic()
    
    #very straight forward
    def exitProgram(self):
        self.close()

    #This will show the time and date of the GUI at the top right
    def showTime(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        label_time = current_time.toString('hh:mm:ss')
        label_date = current_date.toString(Qt.ISODate)
        self.ui.textBrowser.setText(label_date)
        self.ui.textBrowser_2.setText(label_time)
        
#The loop that opens the GUI
if __name__ == "__main__":
    import sys
    import os
    
    current_path = os.getcwd()
    app = QApplication(sys.argv)
    jarvis = Main(path=current_path)
    jarvis.show()
    exit(app.exec_())
